import pathlib

path = str(pathlib.Path(__file__).parent.absolute())
