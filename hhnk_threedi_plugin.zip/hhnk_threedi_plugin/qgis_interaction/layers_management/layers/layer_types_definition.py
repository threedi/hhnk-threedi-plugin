VECTOR = "vector"
HIDDEN = "hidden"
RASTER = "raster"
VIRTUAL = "virtual"
