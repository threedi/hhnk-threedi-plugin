LIZARD_LUCHTFOTO = "contextualWMSLegend=0&crs=EPSG:28992&dpiMode=7&featureCount=10&format=image/png&layers=intern:nl:cover:fun-1801c&styles&url=https://demo.lizard.net/wms/public/?"
PDOK_LUCHTFOTO = "tileMatrixSet=EPSG:28992&crs=EPSG:28992&layers=Actueel_ortho25&styles=default&format=image/jpeg&url=https://service.pdok.nl/hwh/luchtfotorgb/wmts/v1_0"
