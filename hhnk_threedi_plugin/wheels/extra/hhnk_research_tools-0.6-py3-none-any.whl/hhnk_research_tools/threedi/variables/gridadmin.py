# Gridadmin variable names
all_1d = "1D_ALL"
all_2d = "2D_ALL"
