"""Top-level package for condenser."""

__version__ = "0.1.0"

from .query import NumpyQuery  # NOQA
