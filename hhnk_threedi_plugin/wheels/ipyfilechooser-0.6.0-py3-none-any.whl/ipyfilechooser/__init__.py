from .filechooser import FileChooser

__version__ = '0.6.0'
